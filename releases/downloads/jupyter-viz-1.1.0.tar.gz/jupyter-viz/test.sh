#!/bin/sh

gap -b -q < tst/testall.g

