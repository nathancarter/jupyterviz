#!/bin/bash

rm *.min.js

