
# Plan/To-do List

## Bugs

 * Upon re-opening a notebook, all the graphs are dead, because they try to
   call `Jupyter.notebook.kernel.execute` when there is not yet any
   `Jupyter.notebook.kernel` in existence.  Update the `using-runGAP.js`
   file to retry until that thing is defined.

## Documentation

 * Add a chapter to the documentation about how to add a new visualization
   tool to the package.
 * Perfect the manual with Alex's help as follows:
    * Why do I need to use `&nbsp;` elements to get JSON indented?  Is there
      a better way?
    * Is there any way to insert images?  That would be excellent.
    * If I use `@Example...@EndExample`, then it adds one or more (sometimes
      many) GAP prompts.  If I use `<Listing>...</Listing>`, indentation is
      lost.  Neither does syntax highlighting.  Is there a better way?
    * The ToC does not list subsections.  Can I change that?

## Submission

 * Submit to package repository.
