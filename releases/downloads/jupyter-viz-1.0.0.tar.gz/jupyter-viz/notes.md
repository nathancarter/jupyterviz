
# Plan/To-do List

## Bugs

 * Upon re-opening a notebook, all the graphs are dead, because they try to
   call `Jupyter.notebook.kernel.execute` when there is not yet any
   `Jupyter.notebook.kernel` in existence.  Update the `using-runGAP.js`
   file to retry until that thing is defined.

## Documentation

 * Add a chapter to the documentation about how to add a new visualization
   tool to the package.

## Submission

 * Submit to package repository.
